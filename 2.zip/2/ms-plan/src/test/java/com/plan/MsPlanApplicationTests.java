package com.plan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsPlanApplicationTests {

	@Test
	void contextLoads() {
	}

}
